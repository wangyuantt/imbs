/*
 * @Author: Wang Yuan 
 * @Date: 2021-02-28 14:52:51 
 * @Last Modified by: Wang Yuan
 * @Last Modified time: 2021-02-28 14:53:55
 */
<template>
  <div class="real-time-preview rtp">Real-time preview</div>
</template>

<script>
export default {
  name: 'real-time-preview'
}
</script>
