<template>
  <div class="mod-home">
    <h3>综合安防管理平台</h3>
    <ul>
      <li>首页信息展示</li>
    </ul>
  </div>
</template>

<script>
  export default {
    name: 'home'
  }
</script>

<style>
  .mod-home {
    line-height: 1.5;
  }
</style>

